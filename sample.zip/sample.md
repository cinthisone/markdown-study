# Sample Task List

## Daily Tasks
- [ ] Wake up early
- [ ] Exercise for 30 minutes
- [ ] Read a book
- [x] Drink water

## Project Tasks
- [ ] Set up development environment
- [ ] Write documentation
- [x] Create initial prototype
- [ ] Test with users

## Shopping List
- [ ] Buy groceries
  - [ ] Milk
  - [ ] Eggs
  - [ ] Bread
- [x] Order new headphones
- [ ] Pick up dry cleaning

## Notes
You can check/uncheck these items and the state will be saved automatically! 